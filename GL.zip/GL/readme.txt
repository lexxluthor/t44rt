из папки dll копируем в Windows/System32 Windows/SysWOW64
из папки include идем в ProgramFiles(x86) ищем папку Microsoft Visual Studio -> VC -> include и копируем туда все файлы
из папки lib по тому же путю как и include только открываем не include, а lib и копируем туда